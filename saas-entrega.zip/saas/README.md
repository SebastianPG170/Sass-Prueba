# Metsys - Home (Figma "Saas Website")

Abrir `index.html` en el navegador.

- `scss/`: código fuente (`main.scss` importa variables, mixins, base y un archivo por sección en `components/`).
- `css/main.css`: CSS compilado (lo carga `index.html`).
- `img/`: imágenes.
- Compilar: Live Sass Compiler de VS Code ("Watch Sass"); `.vscode/settings.json` ya guarda el CSS en `/css`.
